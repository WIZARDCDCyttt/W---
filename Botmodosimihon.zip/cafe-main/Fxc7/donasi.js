const donasi = (Ig, name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝑴𝑬𝑵𝑫𝑰𝑵𝑮𝑨𝑵𝑫𝑶
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DOAR :)* ❉⊰━━✿
┃  
┣━⊱ *OVO*
┣⊱ 0831180
┣━⊱ *PULSA*
┣⊱ 0831180
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ${WIZARD}*
┗━━━━━━━━━━━━━━━━━━━━
Note:
nao doem se alguem cobrar por bot e porque e passa fome da pra fazer gratis
${Ig}

`
}

exports.donasi = donasi