const help = (prefix, instagram, yt, name, pushname2, user, limitt, uptime, jam, tanggal) => { 
	return `
	

\`\`\`INSTAGRAM OFFICIAL\`\`\`
https://www.instagram.com/invites/contact/?i=ktvlqfgcgxrf&utm_content=aqezmq0 


\`\`\`POR FAVOR, LEIA AS NOTAS ABAIXO ANTES\`\`\`
\`\`\`USANDO O BOT\`\`\`

╭──────「 *REGULAMENTO ${name}* 」
┴
┣⊱  \`\`\`NOMA USUARIO:\`\`\` *${pushname2}*
┣⊱  \`\`\`VERIFICACAO:\`\`\` ✅
┣⊱  \`\`\`LIMITE:\`\`\` *${limitt}*
┣⊱  \`\`\`ATIVO:\`\`\` ${kyun(uptime)}
┣⊱  \`\`\`HORA:\`\`\` *${jam} WIB*
┣⊱  \`\`\`ENCONTRO:\`\`\` *${tanggal}*
┣⊱  \`\`\`VERSAO:\`\`\` *6.5.0*
┣⊱  \`\`\`USUARIO REGISTRADO:\`\`\` *${user.length} User*
┣⊱  ❌ *SPAM*
┣⊱  ❌ *CALL & VC*
┣⊱  \`\`\`Quebra??\`\`\` *Banido*
┬
╰────────────────────────


╭──────「 *SOBRE ${name}* 」
┴
│➻ *${prefix}report lapor bug* primeira git termux com antilink
│➻ *${prefix}info*
│➻ *${prefix}donasi* mendingacao
│➻ *${prefix}owner*
│➻ *${prefix}speed*
│➻ *${prefix}daftar*
│➻ *${prefix}totaluser*
│➻ *${prefix}grouplist*
│➻ *${prefix}blocklist*
│➻ *${prefix}banlist*
│➻ *${prefix}premiumlist*
│➻ *${prefix}bahasa*
┬
╰────────────────────────


͏͏͏͏͏͏͏͏͏͏͏͏͏͏╭──────「 *MEDIA DOWNLOAD* 」
┴
│➻ *${prefix}tiktokstalk username*
│➻ *${prefix}igstalk _LORDE SCREAMO*
│➻ *${prefix}insta Link*
│➻ *${prefix}instastory username*
│➻ *${prefix}ssweb url*
│➻ *${prefix}url2img Url*
│➻ *${prefix}tiktok*
│➻ *${prefix}fototiktok*
│➻ *${prefix}meme*
│➻ *${prefix}memeindo*
│➻ *${prefix}kbbi*
│➻ *${prefix}wait*
│➻ *${prefix}trendtwit*
│➻ *${prefix}google berita terkini*
┬
╰────────────────────────


╭──────「 *CRIADOR MENU* 」
┴
│➻ *${prefix}quotemaker tx/wtrmk/tema*
│➻ *${prefix}nulis nama/kelas/text*
│➻ *${prefix}rain reply image*
│➻ *${prefix}trigger reply image*
│➻ *${prefix}rip reply image*
│➻ *${prefix}wasted reply image*
│➻ *${prefix}cphlogo CAFE/BOT*
│➻ *${prefix}cglitch SCREAMO/BOT*
│➻ *${prefix}cpubg SCREAMO/BOT*
│➻ *${prefix}cml SCREAMO*
│
│➻ *${prefix}tahta SCREAMO*
│➻ *${prefix}croman SCREAMO dan BOT*
│➻ *${prefix}cthunder SCREAMO*
│➻ *${prefix}cbpink SCREAMO*
│➻ *${prefix}cmwolf SCREAMO*
│➻ *${prefix}csky SCREAMO*
│➻ *${prefix}cwooden SCREAMO*
│➻ *${prefix}cflower SCREAMO*
│➻ *${prefix}clove SCREAMO*
│➻ *${prefix}ccrossfire SCREAMO*
│➻ *${prefix}cnaruto SCREAMO*
│➻ *${prefix}cparty SCREAMO*
│➻ *${prefix}cshadow SCREAMO*
│➻ *${prefix}cminion SCREAMO*
│➻ *${prefix}cneon CAFE*
│➻ *${prefix}cneon2 CAFE*
│➻ *${prefix}cneongreen CAFE*
│➻ *${prefix}c3d CAFE*
│➻ *${prefix}csky CAFE*
│➻ *${prefix}tts id Haii*
│➻ *${prefix}ttp Screamo*
│➻ *${prefix}cballon Screamo*
│➻ *${prefix}cpaper Screamo*
│➻ *${prefix}slide Screamo BOT WA*
│
│➻ *${prefix}stiker*
│➻ *${prefix}gifstiker*
│➻ *${prefix}toimg*
│➻ *${prefix}img2url*
│➻ *${prefix}nobg*
│➻ *${prefix}tomp3*
│➻ *${prefix}ocr*
┬
╰──────────────────────────


╭───────「 *GRUPO APENAS* 」
┴
│➻ *${prefix}modeanime On/Off*
│➻ *${prefix}naruto*
│➻ *${prefix}minato*
│➻ *${prefix}boruto*
│➻ *${prefix}hinata*
│➻ *${prefix}sakura*
│➻ *${prefix}sasuke*
│➻ *${prefix}kaneki*
│➻ *${prefix}toukachan*
│➻ *${prefix}rize*
│➻ *${prefix}akira*
│➻ *${prefix}itori*
│➻ *${prefix}kurumi*
│➻ *${prefix}miku*
│➻ *${prefix}anime*
│➻ *${prefix}animecry*
│➻ *${prefix}neonime*
│➻ *${prefix}animekiss*
│➻ *${prefix}wink*
┬
╰───────────────────────

╭────────────────────────
┴
│➻ *${prefix}welcome On/Off*
│➻ *${prefix}grup buka/tutup*
│➻ *${prefix}antilink on/off*
│➻ *${prefix}ownergrup*
│➻ *${prefix}setpp*
│➻ *${prefix}infogc*
│➻ *${prefix}add*
│➻ *${prefix}kick*
│➻ *${prefix}promote*
│➻ *${prefix}demote*
│➻ *${prefix}setname* muda nome grupo 
│➻ *${prefix}setdesc* altera descricao
│➻ *${prefix}linkgrup*
│➻ *${prefix}tagme*
│➻ *${prefix}hidetag* marcar invisivel
│➻ *${prefix}tagall*
│➻ *${prefix}mentionall* menciona membro
│➻ *${prefix}fitnah*
│➻ *${prefix}listadmin*
│➻ *${prefix}openanime*
│➻ *${prefix}edotense*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}nsfw On/Off*
│➻ *${prefix}nsfwloli*
│➻ *${prefix}nsfwblowjob*
│➻ *${prefix}nsfwneko*
│➻ *${prefix}nsfwtrap*
│➻ *${prefix}hentai* ja sabe aqui e foto doida 
│➻ *${prefix}simih On/Off*
┬
╰────────────────────────


╭──────「 *OTHERS FUN & GAME* 」
┴
│➻ *${prefix}anjing*
│➻ *${prefix}kucing*
│➻ *${prefix}testime*
│➻ *${prefix}hilih*
│➻ *${prefix}say*
│➻ *${prefix}apakah*
│➻ *${prefix}kapankah*
│➻ *${prefix}bisakah*
│➻ *${prefix}rate*
│➻ *${prefix}watak*
│➻ *${prefix}hobby*
│➻ *${prefix}infogempa*
│➻ *${prefix}infonomor*
│➻ *${prefix}quotes*
│➻ *${prefix}truth*
│➻ *${prefix}dare*
│➻ *${prefix}katabijak*
│➻ *${prefix}fakta*
│➻ *${prefix}darkjokes*
│➻ *${prefix}bucin*
│➻ *${prefix}pantun*
│➻ *${prefix}katacinta*
│➻ *${prefix}jadwaltvnow*
│➻ *${prefix}hekerbucin*
│➻ *${prefix}katailham*
│➻ *${prefix}animewp*
┬
╰────────────────────────

╭──────────────────────────
┴
│➻ *${prefix}jarak Banyuwangi/Surabaya*
│➻ *${prefix}translate en/Apa kabar?*
│➻ *${prefix}pasangan Farhan/Iriene*
│➻ *${prefix}gantengcek Farhan*
│➻ *${prefix}cantikcek Iriene*
│➻ *${prefix}artinama Farhan*
│➻ *${prefix}persengay Topan*
│➻ *${prefix}pbucin Farhan*
│➻ *${prefix}bpfont Farhan*
│➻ *${prefix}textstyle SCREAMO*
│➻ *${prefix}jadwaltv antv*
│➻ *${prefix}lirik melukis senja*
│➻ *${prefix}chord Melukis senja*
│➻ *${prefix}wiki Adolf Hitler*
│➻ *${prefix}brainly pertanyaan*
│➻ *${prefix}resepmasakan rawon*
│➻ *${prefix}map Banyuwangi*
│➻ *${prefix}film Fast and Farious*
│➻ *${prefix}pinterest gambar kucing*
│➻ *${prefix}infocuaca Banyuwangi*
│➻ *${prefix}jamdunia Banyuwangi*
│➻ *${prefix}mimpi Ular*
│➻ *${prefix}infoalamat jalan Banyuwangi*
│➻ *${prefix}playstore WhatsApp*
┬
╰───────────────────────────


╭────────────────────────
┴
│➻ *${prefix}asupan*
│➻ *${prefix}tebakgambar*
│➻ *${prefix}caklontong*
│➻ *${prefix}family100*
│➻ *${prefix}kalkulator 13*12*
│➻ *${prefix}wp gunung*
│➻ *${prefix}moddroid lightroom*
│➻ *${prefix}happymod lightroom*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}cerpen*
│➻ *${prefix}cersex*
│➻ *${prefix}xxx japan*
│➻ *${prefix}pornhub stepMoms* pornozao kkk
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}jadwalsholat Banyuwangi*
│➻ *${prefix}quran*
│➻ *${prefix}quransurah 1*
│➻ *${prefix}tafsir kafir*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}becrypt string*
│➻ *${prefix}encode64 string*
│➻ *${prefix}decode64 encrypt*
│➻ *${prefix}encode32 string*
│➻ *${prefix}decode32 encrypt*
│➻ *${prefix}encbinary string*
│➻ *${prefix}decbinary encrypt*
│➻ *${prefix}encoctal string*
│➻ *${prefix}decoctal encrypt*
│➻ *${prefix}hashidentifier Encrypt Hash*
│➻ *${prefix}dorking dork*
│➻ *${prefix}pastebin teks*
│➻ *${prefix}tinyurl link*
│➻ *${prefix}bitly link*
┬
╰────────────────────────

╭────────────────────────
┴
│➻ *${prefix}spamcall 083xxxxxxxxx*
│➻ *${prefix}spamsms 083xxxxxxxx/jumlah*
│➻ *${prefix}spamgmail lordescreamo@gmail.com*
┬
╰────────────────────────


╭─────────「 *SO PROPRIETARIO* 」
┴
│➻ *${prefix}addprem mentioned*
│➻ *${prefix}removeprem mention*
│➻ *${prefix}setmemlimit*
│➻ *${prefix}setreply*
│➻ *${prefix}setprefix*
│➻ *${prefix}setnamebot* muda nome desse bot
│➻ *${prefix}setppbot*
│➻ *${prefix}bc*
│➻ *${prefix}bcgc*
│➻ *${prefix}ban*
│➻ *${prefix}unban*
│➻ *${prefix}block*
│➻ *${prefix}unblock*
│➻ *${prefix}clearall*
│➻ *${prefix}delete*
│➻ *${prefix}clone*
│➻ *${prefix}getses*
│➻ *${prefix}leave*
┬
╰────────────────────────


╭────────「 *PREMIUM APENAS* 」
┴
│➻ *${prefix}playmp3 menepi*
│➻ *${prefix}fb link video*
│➻ *${prefix}snack link snack video*
│➻ *${prefix}ytmp3 link yt* ta baixando musicas youTube
│➻ *${prefix}ytmp4 link yt*
│➻ *${prefix}joox The Ultimate Monologue*
│➻ *${prefix}smule Link Video Smule*
┬
╰────────────────────────


╭─────「 *CANAIS PARCEIROS${name}* 」
│
├➲ *COPIADOR UCHIHA*
├➲ *MAFIA DOS TUTORS*
├➲ *PROFESSIONNEL JOKER*
├➲ *CORTES SCREAMO*
├➲ *BOT LORDE SCREAMO*
╰────────────────────────`
}

exports.help = help

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}
